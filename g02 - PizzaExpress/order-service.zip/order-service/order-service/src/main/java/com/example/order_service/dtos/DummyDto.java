package com.example.order_service.dtos;

public class DummyDto {
}
