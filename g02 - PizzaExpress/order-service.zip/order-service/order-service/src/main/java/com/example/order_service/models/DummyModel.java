package com.example.order_service.models;

public class DummyModel {
}
